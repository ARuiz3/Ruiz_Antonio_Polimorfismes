public class Main {
    public static void main(String[] args) {
        Camion v = new Camion("dasa21243");
        v.ponRemolque(243);
    }
}