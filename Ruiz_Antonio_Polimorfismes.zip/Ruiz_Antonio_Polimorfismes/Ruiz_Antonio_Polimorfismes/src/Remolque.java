public class Remolque {
    protected int peso;

    public Remolque(int peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Clases.Remolque{" +
                "peso=" + peso +
                '}';
    }
}
